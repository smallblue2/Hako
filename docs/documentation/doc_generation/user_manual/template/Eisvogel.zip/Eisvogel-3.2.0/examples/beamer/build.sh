pandoc "document.md" -o "document.pdf" --from markdown --to beamer --template "../../dist/eisvogel.beamer" --listings
